esp01.o: esp01.c
esp01.o: C:\KeilARM\ARM\RV31\INC\string.h
esp01.o: lcd.h
esp01.o: types.h
esp01.o: uart.h
esp01.o: delay.h
esp01.o: lcd_defines.h

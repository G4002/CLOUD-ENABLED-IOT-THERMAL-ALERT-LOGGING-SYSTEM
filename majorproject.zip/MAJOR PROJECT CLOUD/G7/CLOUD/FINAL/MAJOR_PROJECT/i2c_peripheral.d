i2c_peripheral.o: i2c_peripheral.c
i2c_peripheral.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
i2c_peripheral.o: delay.h
i2c_peripheral.o: types.h
i2c_peripheral.o: pin_connect_block.h
i2c_peripheral.o: pin_function_defines.h
i2c_peripheral.o: i2c_defines.h

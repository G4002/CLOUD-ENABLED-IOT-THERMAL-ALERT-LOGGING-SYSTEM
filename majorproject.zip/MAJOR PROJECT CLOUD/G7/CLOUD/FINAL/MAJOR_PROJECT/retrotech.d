retrotech.o: RETROTECH.c
retrotech.o: lcd.h
retrotech.o: types.h
retrotech.o: delay.h
retrotech.o: lcd_defines.h

// Testing Purpose.
#include  "HEADERS.H"
#include  "INIT_DEVICES.H"

main()
{
	   Initailize();  
	   esp01_connectAP();
	   esp01_sendsetpoint("77.23");
	   ReadSetpointFromESP_01(setpoint_value_cloud);
	   Setcursor(1,0);
	   StrLCD(setpoint_value_cloud);
	   Setcursor(2,0);
	   setpoint_cloud = myatof(setpoint_value_cloud) +  0.00001;
	   F32LCD(setpoint_cloud,2);
	   while(1);

}

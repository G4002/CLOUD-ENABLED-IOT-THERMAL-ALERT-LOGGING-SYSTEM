adc.o: adc.c
adc.o: pin_connect_block.h
adc.o: types.h
adc.o: delay.h
adc.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.h
adc.o: adc_defines.h
adc.o: pin_function_defines.h

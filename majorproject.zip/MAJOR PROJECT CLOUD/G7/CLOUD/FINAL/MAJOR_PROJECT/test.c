
#include "headers.h"
#include "init_Devices.h"

int b;

main()
{
	
	
	Initailize();        CmdLCD(0x01); 
							   Setcursor(1,0);
							  // CharLCD(0x23);
							  
							   StrLCD("Reading Setpoint.");
								 Setcursor(2,0);
								
								 for(b=0;b<16;b++)
								 {
									 CharLCD(0x5F);
									 delay_Ms(10);
								 }
						
					
     while(1)
		 {
		        GetRTCTimeInfo(&v.hour,&v.min,&v.sec);
			      DisplayRTCTime(v.hour,v.min,v.sec);
			      // ReadSetpointFromESP_01();
			      //setpoint_cloud = myatof(setpoint_value_cloud) +  0.00001;      // STORING THE SETPOINT FROM THE CLOUD WHICH IS RECENTLY CHANGED AND EVERYTIME CHECKING.
			      
			      
			      // NOW  COMPARING IT WITH EEPROM RELATED SETPOINT.
			      // IF EQUAL FINE OTHERWISE WE NEED TO ASSIGN THE CLOUD SETPOINT.
			      
			     /* if(setpoint != setpoint_cloud)
						{
							// STEP1: NEED TO CHANGE THE EEPROM SETPOINT WITH CLOUD SETPOINT.
							I2C_EEPROM_PAGEWRITE(EEPROM_SENSOR ,0x0010 ,setpoint_value_cloud , mylen(setpoint_value_cloud));
							// NOW REPLACE THE SETPOINT WITH NEW ONE.
							setpoint = myatof(setpoint_value_cloud) +  0.00001;
						}*/
						if(isr_flag)
						{
							   isr_flag = 0;
							   CmdLCD(0x01); 
							   Setcursor(1,0);
							   CharLCD(0x1A);
							   uart_isr = 0;
							   StrLCD("Reading temp");
							   
							   while(1);
							  // esp01_sendsetpoint(setpoint_value);
							   /*Setcursor(1,0);
							   StrLCD("Updating......");
							   delay_Ms(300);
							   I2C_EEPROM_PAGEWRITE(EEPROM_SENSOR ,0x0010 ,setpoint_value , setpoint);
							   CmdLCD(CLEAR_LCD);*/
							 
						}
						if(flag)
						{
							   flag=0;
							   Read_Temperature('c',&temperature);
							   myftoa(temperature);
							   //esp01_sendToThingspeak(sensor_value);
                 min = v.min + 2;
                 sec = v.sec;							
						}
						Display_temperature_on_LCD();
						if(v.min == min && sec <= v.sec )
							    flag = 1;
					}

	
	
}

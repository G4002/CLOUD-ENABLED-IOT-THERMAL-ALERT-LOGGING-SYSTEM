lcd.o: lcd.c
lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
lcd.o: defines.h
lcd.o: delay.h
lcd.o: types.h
lcd.o: lcd.h
lcd.o: lcd_defines.h

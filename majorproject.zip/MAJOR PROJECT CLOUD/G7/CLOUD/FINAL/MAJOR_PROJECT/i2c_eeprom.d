i2c_eeprom.o: i2c_eeprom.c
i2c_eeprom.o: TYPES.H
i2c_eeprom.o: DELAY.H
i2c_eeprom.o: I2C_PERIPHERAL.H

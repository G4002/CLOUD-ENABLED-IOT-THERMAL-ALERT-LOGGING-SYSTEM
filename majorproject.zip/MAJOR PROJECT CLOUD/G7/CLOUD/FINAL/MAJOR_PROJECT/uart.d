uart.o: uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
uart.o: pin_connect_block.h
uart.o: types.h
uart.o: pin_function_defines.h
uart.o: uart_defines.h
uart.o: delay.h

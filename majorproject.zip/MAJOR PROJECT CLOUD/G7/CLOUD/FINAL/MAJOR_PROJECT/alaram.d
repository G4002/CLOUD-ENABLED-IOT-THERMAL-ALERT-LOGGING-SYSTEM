alaram.o: alaram.c
alaram.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
alaram.o: defines.h

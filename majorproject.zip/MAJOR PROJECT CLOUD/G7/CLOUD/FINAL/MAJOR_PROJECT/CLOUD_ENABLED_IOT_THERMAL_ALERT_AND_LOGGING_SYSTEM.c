
/**  CLOUD ENABLED IOT THERMAL ALERT AND LOGGING SYSTEM **/


#include  "HEADERS.H"
#include  "INIT_DEVICES.H"
 
 
int main()
{
	  
	   Initailize();                // ALL INTERFACECS INTIALIZING.
     
	   BeforeWhile();               // INITIAL SETPOINT TO CLOUD AND ALSO TO THE EEPROM.
     // min = MIN + 2;
     while(1)
     {
		           GetRTCTimeInfo(&v.hour,&v.min,&v.sec);
			          DisplayRTCTime(v.hour,v.min,v.sec);
				 							 Read_Temperature('c',&temperature);
				  						 delay_Ms(250);
			          Display_temperature_on_LCD(); 
			          // INTERRUPT RELATED FLAG.
             // SETPOINT BY MANUALLY.			 
			 
						if(isr_flag)
						{
							   isr_flag = 0;
							   esp01_sendsetpoint(setpoint_value);
							   Setcursor(1,0);
							   StrLCD("Updating......");
							   delay_Ms(300);
							   I2C_EEPROM_PAGEWRITE(EEPROM_SENSOR ,0x0010 ,setpoint_value , 5);
							   setpoint = myatof(setpoint_value) + 0.00001f;
							   delay_Ms(1000);
							   CmdLCD(CLEAR_LCD);
							 
						}
						if(flag)
						{
						         
						             I2C_EEPROM_SEQREAD(EEPROM_SENSOR ,0x0010 ,setpoint_value , 5);
						             setpoint = myatof(setpoint_value) + 0.00001f;
							         flag=0;
							         CmdLCD(CLEAR_LCD);
							         Setcursor(1,0);
							         CharLCD(0x23);
							         StrLCD("Reading LM35..");
								     Setcursor(2,0);
							
								 for(k=0;k<16;k++)
								 {
									 CharLCD(0x5F);
									 delay_Ms(10);
								 }
								 delay_Ms(300);
							         Read_Temperature('c',&temperature);
							         myftoa(temperature);
								 CmdLCD(CLEAR_LCD);
								 Setcursor(1,0);
								 StrLCD("Reading Temperature");
								 delay_Ms(200);
								 CmdLCD(CLEAR_LCD);
								 Setcursor(1,0);
							     StrLCD("sending to cloud.");
								 Setcursor(2,0);
								
								 for(k=0;k<16;k++)
								 {
									 CharLCD(0x5F);
									 delay_Ms(10);
								 }
							         esp01_sendToThingspeak(sensor_value);
                                     min = MIN + 2;
							         if(min > 60)
								     {
									 min = min - 60;
								     }
                                     sec = SEC;	
								 if(sec > 60)
								 {
									 sec = sec - 60;
								 }
								 
								 CmdLCD(CLEAR_LCD);
							         StrLCD("Reading Setpoint.");
								 Setcursor(2,0);
								
								 for(k=0;k<16;k++)
								 {
									 CharLCD(0x5F);
									 delay_Ms(10);
								 }
                                 ReadSetpointFromESP_01(setpoint_value_cloud);
								 CmdLCD(CLEAR_LCD);
			                     setpoint_cloud = myatof(setpoint_value_cloud)+0.00001f;      // STORING THE SETPOINT FROM THE CLOUD WHICH IS RECENTLY CHANGED AND EVERYTIME CHECKING.
                                 //setpoint = setpoint_cloud;
								 if(setpoint_cloud > 150.0)
								 {
									  esp01_sendsetpoint(setpoint_value);
                                      setpoint_cloud = setpoint;							 
								 }									 
						}
						
						
						// NOW  COMPARING IT WITH EEPROM RELATED SETPOINT.
			            // IF EQUAL FINE OTHERWISE WE NEED TO ASSIGN THE CLOUD SETPOINT.
						
						if(setpoint != setpoint_cloud)
						{
							// STEP1: NEED TO CHANGE THE EEPROM SETPOINT WITH CLOUD SETPOINT.
							I2C_EEPROM_PAGEWRITE(EEPROM_SENSOR ,0x0010 ,setpoint_value_cloud , mylen(setpoint_value_cloud));
							// NOW REPLACE THE SETPOINT WITH NEW ONE.
							setpoint = myatof(setpoint_value_cloud) +  0.00001f;
						}
						if((MIN == min && sec <= SEC ))
							    flag = 1;
						if(temperature >= setpoint)
						{
							  
							  IOSET0 = 1<<16;
						}
                                                else
						{ 
							  IOCLR0 = 1<<16;
						}							
		 }	
	 }		 


